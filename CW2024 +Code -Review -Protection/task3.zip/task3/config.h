#ifndef CONFIG_H
#define CONFIG_H

struct TabulateConfig {
    double start {0};
    double end {0};
    double step {0};
};

#endif // CONFIG_H
